﻿Imports MySql.Data.MySqlClient
Public Class Login
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        clear()
    End Sub
    Sub clear()
        TextBox1.Text = ""
    End Sub
    Private Sub B1_Click(sender As Object, e As EventArgs) Handles B1.Click
        If TextBox1.Text <> "0" And TextBox1.Text.Length() < 8 Then
            TextBox1.Text += "1"
        Else
            TextBox1.Text = "1"
        End If
    End Sub
    Private Sub B2_Click(sender As Object, e As EventArgs) Handles B2.Click
        If TextBox1.Text <> "0" And TextBox1.Text.Length() < 8 Then
            TextBox1.Text += "2"
        Else
            TextBox1.Text = "2"
        End If
    End Sub
    Private Sub B3_Click(sender As Object, e As EventArgs) Handles B3.Click
        If TextBox1.Text <> "0" And TextBox1.Text.Length() < 8 Then
            TextBox1.Text += "3"
        Else
            TextBox1.Text = "3"
        End If
    End Sub
    Private Sub B4_Click(sender As Object, e As EventArgs) Handles B4.Click
        If TextBox1.Text <> "0" And TextBox1.Text.Length() < 8 Then
            TextBox1.Text += "4"
        Else
            TextBox1.Text = "4"
        End If
    End Sub
    Private Sub B5_Click(sender As Object, e As EventArgs) Handles B5.Click
        If TextBox1.Text <> "0" And TextBox1.Text.Length() < 8 Then
            TextBox1.Text += "5"
        Else
            TextBox1.Text = "5"
        End If
    End Sub
    Private Sub B6_Click(sender As Object, e As EventArgs) Handles B6.Click
        If TextBox1.Text <> "0" And TextBox1.Text.Length() < 8 Then
            TextBox1.Text += "6"
        Else
            TextBox1.Text = "6"
        End If
    End Sub
    Private Sub B7_Click(sender As Object, e As EventArgs) Handles B7.Click
        If TextBox1.Text <> "0" And TextBox1.Text.Length() < 8 Then
            TextBox1.Text += "7"
        Else
            TextBox1.Text = "7"
        End If
    End Sub
    Private Sub B8_Click(sender As Object, e As EventArgs) Handles B8.Click
        If TextBox1.Text <> "0" And TextBox1.Text.Length() < 8 Then
            TextBox1.Text += "8"
        Else
            TextBox1.Text = "8"
        End If
    End Sub
    Private Sub B9_Click(sender As Object, e As EventArgs) Handles B9.Click
        If TextBox1.Text <> "0" And TextBox1.Text.Length() < 8 Then
            TextBox1.Text += "9"
        Else
            TextBox1.Text = "9"
        End If
    End Sub
    Private Sub B10_Click(sender As Object, e As EventArgs) Handles B10.Click
        If TextBox1.Text <> "0" And TextBox1.Text.Length() < 8 Then
            TextBox1.Text += "0"
        Else
            TextBox1.Text = "0"
        End If
    End Sub
    Private Sub b_ext_Click(sender As Object, e As EventArgs) Handles b_ext.Click
        Application.Exit()
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If TextBox1.UseSystemPasswordChar = True Then
            TextBox1.UseSystemPasswordChar = False
        Else
            TextBox1.UseSystemPasswordChar = True
        End If
    End Sub
    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox1.UseSystemPasswordChar = False
        Timer1.Enabled = True
        autogenerate()
    End Sub
    Sub autogenerate()
        connect()
        Try
            Dim sql As String = "SELECT Max(loghistory_id) From log_history"
            Dim cm As New MySqlCommand(sql, conn)
            Dim numbers As Integer

            If IsDBNull(cm.ExecuteScalar) Then
                numbers = 1
                Label6.Text = numbers
            Else
                numbers = cm.ExecuteScalar + 1
                Label6.Text = numbers
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        conn.Close()
    End Sub
    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        e.Handled = Char.IsDigit(e.KeyChar) Or Not Char.IsDigit(e.KeyChar)
    End Sub

    Private Sub b_ok_Click(sender As Object, e As EventArgs) Handles b_ok.Click

        connect()
        Dim query As String = "select * from login_user,staff, position where login_user.staff_id = staff.staff_id AND staff.p_id = position.p_id AND position = 'MANAGER'  AND status != 'Deactivated'  AND login_user.pincode ='" & TextBox1.Text & "'"
        Dim com As New MySqlCommand(query, conn)
        Dim dr = com.ExecuteReader
        Dim count As Integer = 0
        While dr.Read
            count = count + 1
        End While

        connect()
        Dim query1 As String = "select * from login_user,staff, position where login_user.staff_id = staff.staff_id AND staff.p_id = position.p_id AND position = 'Cashier' AND status != 'Deactivated' AND login_user.pincode ='" & TextBox1.Text & "'"
        Dim com1 As New MySqlCommand(query1, conn)
        Dim dr1 = com1.ExecuteReader
        Dim count1 As Integer = 0
        While dr1.Read
            count1 = count + 1
        End While

        If count = 1 Then
            Dim main As Admin
            main = New Admin
            main.Show()
            main = Nothing
            Me.Hide()
        ElseIf count1 = 1 Then
            Dim main As Cashier
            main = New Cashier
            main.Show()
            main = Nothing
            Me.Hide()
        Else
            MsgBox("INVALID! Thank you :)  ", MsgBoxStyle.Critical)

        End If
        clear()
        conn.Close()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label4.Text = Date.Now.ToString("dd MMM yyyy")
        Label5.Text = Date.Now.ToString("hh:mm:ss")
    End Sub

End Class
