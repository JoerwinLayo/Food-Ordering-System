﻿Imports MySql.Data.MySqlClient
Public Class Positionlist
    Sub clear()
        TextBox1.Text = ""
    End Sub
    Private Sub Positionlist_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        autogenerate()
        retrieves()
    End Sub
    Sub retrieves()
        connect()
        Dim dr As MySqlDataReader
        ListView1.Items.Clear()
        Try
            Dim query As String = "SELECT * FROM view_position"
            Dim com As New MySqlCommand(query, conn)
            dr = com.ExecuteReader
            While dr.Read
                With ListView1.Items.Add(dr("p_id").ToString)
                    .SubItems.Add(dr("position").ToString)
                End With
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Sub autogenerate()
        connect()
        Try
            Dim sql As String = "SELECT * From view_position_generate"
            Dim cm As New MySqlCommand(sql, conn)
            Dim numbers As Integer

            If IsDBNull(cm.ExecuteScalar) Then
                numbers = 1
                idTextBox.Text = numbers
            Else
                numbers = cm.ExecuteScalar + 1
                idTextBox.Text = numbers
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        conn.Close()
    End Sub
    Private Sub addBtn_Click(sender As Object, e As EventArgs) Handles addBtn.Click
        If idTextBox.Text = "" Or TextBox1.Text = "" Then
            MessageBox.Show("Fill the blanks to insert data!", "Textfields Empty", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            Dim connection As New MySqlConnection("server=localhost;user id=root;database=ordering_softeng")
            Dim params(0) As MySqlParameter
            params(0) = New MySqlParameter("PS", MySqlDbType.VarChar)
            params(0).Value = TextBox1.Text
            Dim cmd As New MySqlCommand()
            cmd.Connection = connection
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "insert_position"
            cmd.Parameters.AddRange(params)
            connection.Open()
            If cmd.ExecuteNonQuery() = 1 Then
                MessageBox.Show("Data Successfully Inserted!", "Inserted Successfull", MessageBoxButtons.OK, MessageBoxIcon.Information)
                retrieves()
                autogenerate()
                clear()
            Else
                MessageBox.Show("Not inserted")
            End If
            connection.Close()
        End If
    End Sub
    Private Sub updateBtn_Click(sender As Object, e As EventArgs) Handles updateBtn.Click
        If idTextBox.Text = "" Or TextBox1.Text = "" Then
            MessageBox.Show("Please Choose to update!", "Textfields Empty", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            Dim connection As New MySqlConnection("server=localhost;user id=root;database=ordering_softeng")
            Dim params(1) As MySqlParameter
            params(0) = New MySqlParameter("ID", MySqlDbType.Int32)
            params(0).Value = idTextBox.Text
            params(1) = New MySqlParameter("NAME", MySqlDbType.VarChar)
            params(1).Value = TextBox1.Text
            Dim cmd As New MySqlCommand()
            cmd.Connection = connection
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "update_pos"
            cmd.Parameters.AddRange(params)
            connection.Open()
            cmd.ExecuteNonQuery()
            MessageBox.Show("Data Successfully Updated!", "Update Successfull", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            retrieves()
            autogenerate()
            clear()
            connection.Close()
        End If
    End Sub
    Private Sub deleteBtn_Click(sender As Object, e As EventArgs) Handles deleteBtn.Click
        If idTextBox.Text = "" Or TextBox1.Text = "" Then
            MessageBox.Show("Please Choose to delete!", "Textfields Empty", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            Dim connection As New MySqlConnection("server=localhost;user id=root;database=ordering_softeng")
            Dim params(0) As MySqlParameter
            params(0) = New MySqlParameter("ID", MySqlDbType.Int32)
            params(0).Value = idTextBox.Text
            Dim cmd As New MySqlCommand()
            cmd.Connection = connection
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "delete_pos"
            cmd.Parameters.AddRange(params)
            connection.Open()
            cmd.ExecuteNonQuery()
            MessageBox.Show("Data Successfully Deleted!", "Delete Successfull", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            retrieves()
            autogenerate()
            clear()
            connection.Close()
        End If
    End Sub
    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged
        Dim index = ListView1.FocusedItem.Index
        idTextBox.Text = ListView1.Items(index).Text
        TextBox1.Text = ListView1.Items(index).SubItems(1).Text
    End Sub
    Private Sub closeBtn_Click(sender As Object, e As EventArgs) Handles closeBtn.Click
        Me.Hide()
    End Sub
    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        e.Handled = e.KeyChar <> ChrW(Keys.Back) And Not Char.IsSeparator(e.KeyChar) And Not Char.IsLetter(e.KeyChar)
    End Sub

    Private Sub idTextBox_KeyPress(sender As Object, e As KeyPressEventArgs) Handles idTextBox.KeyPress
        e.Handled = Char.IsDigit(e.KeyChar) Or Not Char.IsDigit(e.KeyChar)
    End Sub

End Class