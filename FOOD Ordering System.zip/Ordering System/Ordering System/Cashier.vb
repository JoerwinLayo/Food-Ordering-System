﻿Imports MySql.Data.MySqlClient
Imports System.Globalization
Imports System.IO
Imports Microsoft.Office.Interop

Public Class Cashier
    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        If PictureBox2.Visible = True Then
            PictureBox2.Visible = False
            Panel2.Show()
        End If
    End Sub
    Private Sub Panel2_MouseClick(sender As Object, e As MouseEventArgs) Handles Panel2.MouseClick
        If PictureBox2.Visible = False Then
            PictureBox2.Visible = True
        End If
    End Sub

    Private Sub TextBox3_KeyPress(sender As Object, e As KeyPressEventArgs)
        e.Handled = Char.IsDigit(e.KeyChar) Or Not Char.IsDigit(e.KeyChar)
    End Sub
    Sub updates_log()

        Dim connection As New MySqlConnection("server=localhost;user id=root;database=ordering_softeng")

        Dim parameters(2) As MySqlParameter

        parameters(0) = New MySqlParameter("LOG", MySqlDbType.VarChar)
        parameters(0).Value = Label15.Text
        parameters(1) = New MySqlParameter("DATE", MySqlDbType.VarChar)
        parameters(1).Value = Login.Label4.Text
        parameters(2) = New MySqlParameter("TM", MySqlDbType.VarChar)
        parameters(2).Value = Login.Label5.Text

        Dim cmd As New MySqlCommand()
        cmd.Connection = connection
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "update_loghistory"
        cmd.Parameters.AddRange(parameters)
        connection.Open()
        cmd.ExecuteNonQuery()
        clear()
        connection.Close()
    End Sub
    Private Sub LogOutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogOutToolStripMenuItem.Click
        updates_log()
        Login.Show()
        Me.Hide()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label32.Text = Date.Now.ToString("hh:mm:ss")

    End Sub
    Sub retrieves()
        connect()
        Dim dr As MySqlDataReader
        ListView2.Items.Clear()
        Try
            Dim query As String = "SELECT * FROM view_foods_category"
            Dim com As New MySqlCommand(query, conn)
            dr = com.ExecuteReader
            While dr.Read
                With ListView2.Items.Add(dr("food_id").ToString)
                    .SubItems.Add(dr("foodname").ToString)
                    .SubItems.Add(dr("price").ToString)
                    .SubItems.Add(dr("quantity").ToString)
                End With
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Sub retrieves1()
        connect()
        Dim dr As MySqlDataReader
        ListView3.Items.Clear()
        Try
            Dim query As String = "SELECT * FROM view_category_lunch"
            Dim com As New MySqlCommand(query, conn)
            dr = com.ExecuteReader
            While dr.Read
                With ListView3.Items.Add(dr("food_id").ToString)
                    .SubItems.Add(dr("foodname").ToString)
                    .SubItems.Add(dr("price").ToString)
                    .SubItems.Add(dr("quantity").ToString)
                End With
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Sub retrieves2()
        connect()
        Dim dr As MySqlDataReader
        ListView4.Items.Clear()
        Try
            Dim query As String = "SELECT * FROM view_category_dinner"
            Dim com As New MySqlCommand(query, conn)
            dr = com.ExecuteReader
            While dr.Read
                With ListView4.Items.Add(dr("food_id").ToString)
                    .SubItems.Add(dr("foodname").ToString)
                    .SubItems.Add(dr("price").ToString)
                    .SubItems.Add(dr("quantity").ToString)
                End With
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub Cashier_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Enabled = True
        Dim dt As String = ""
        Dim dtinfo As DateTimeFormatInfo
        Dim dtstyle As String = "MM/dd/yyyy"
        dtinfo = DateTimeFormatInfo.InvariantInfo
        dt = DateTime.Now.ToString(dtstyle, dtinfo)
        Label2.Text = dt
        retrieves()
        retrieves1()
        retrieves2()
        invoiceNo()
        autos()
        DisplayEmployee(Login.TextBox1.Text)
        insert_log()
    End Sub

    Sub insert_log()
        Dim connection As New MySqlConnection("server=localhost;user id=root;database=ordering_softeng")

        Dim parameters(2) As MySqlParameter

        parameters(0) = New MySqlParameter("ID", MySqlDbType.VarChar)
        parameters(0).Value = Label15.Text

        parameters(1) = New MySqlParameter("DT", MySqlDbType.VarChar)
        parameters(1).Value = Login.Label4.Text

        parameters(2) = New MySqlParameter("TM", MySqlDbType.VarChar)
        parameters(2).Value = Login.Label5.Text

        Dim cmd As New MySqlCommand()
        cmd.Connection = connection
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "insertLogHistory"
        cmd.Parameters.AddRange(parameters)
        connection.Open()
        If cmd.ExecuteNonQuery() = 1 Then
            Login.autogenerate()
            clear()
        Else
        End If
        connection.Close()
    End Sub

    Sub autos()
        connect()
        Try
            Dim sql As String = "SELECT * from view_transaction_generated"
            Dim comm = New MySqlCommand(sql, conn)
            Dim number As Integer

            If IsDBNull(comm.ExecuteScalar) Then
                number = 1
                Label17.Text = number.ToString()
            Else
                number = comm.ExecuteScalar + 1
                Label17.Text = number.ToString()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        conn.Close()
    End Sub
    Sub DisplayEmployee(ByVal password As String)
        connect()
        Try
            Dim query As String
            query = "SELECT * FROM `login_user` , `staff` , `position`  where login_user.staff_id = staff.staff_id  AND  staff.p_id = position.p_id AND pincode = @password"
            Dim comm As New MySqlCommand(query, conn)
            comm.Parameters.AddWithValue("@password", password)
            Dim reader = comm.ExecuteReader
            While reader.Read
                Dim id As String = reader.GetString("login_id")
                Label15.Text = id
                Dim name As String = reader.GetString("f_name")
                Label3.Text = name
                Dim position As String = reader.GetString("position")
                Label5.Text = position

                Dim images() As Byte = reader("image")
                If images.Equals(Nothing) Then
                    PictureBox1.Image = Nothing
                Else
                    Dim ms As New MemoryStream(images)
                    PictureBox1.Image = Image.FromStream(ms)
                End If
            End While

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        conn.Close()
    End Sub
    Sub invoiceNo()
        connect()
        Try
            Dim sql As String = "SELECT * from view_invoice"
            Dim comm = New MySqlCommand(sql, conn)
            Dim number As Integer

            If IsDBNull(comm.ExecuteScalar) Then
                number = 1
                invoiceLabel.Text = number.ToString()
            Else
                number = comm.ExecuteScalar + 1
                invoiceLabel.Text = number.ToString()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        conn.Close()
    End Sub


    Private Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click
        If TextBox3.Text = "0" Or TextBox1.Text = "0" Then
            MessageBox.Show("Fill th blank the transaction first to in sales data!", "Textfields Empty", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            TOTALCASH()
        End If
    End Sub

    Private Sub ListView2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView2.SelectedIndexChanged
        Dim index = ListView2.FocusedItem.Index
        Label9.Text = ListView2.Items(index).Text
        showinfo(Label9.Text)
    End Sub
    Sub showinfo(ByVal food As String)
        connect()
        Try
            Dim query As String = "SELECT * FROM foods where food_id = @food"
            Dim comm = New MySqlCommand(query, conn)
            comm.Parameters.AddWithValue("@food", food)
            Dim dr = comm.ExecuteReader
            While dr.Read
                Label9.Text = dr("food_id").ToString
                Label6.Text = dr("foodname").ToString
                TextBox6.Text = dr("price").ToString
                TextBox2.Text = dr("quantity").ToString

                Dim images() As Byte = dr("image")
                If images.Equals(Nothing) Then
                    PictureBox2.Image = Nothing
                Else
                    Dim ms As New MemoryStream(images)
                    PictureBox2.Image = Image.FromStream(ms)
                End If
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        conn.Close()
    End Sub
    Sub clear()
        PictureBox2.Image = Nothing
        TextBox2.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = "0"
        TextBox6.Text = ""
        TextBox1.Text = ""
        TextBox3.Text = "0"
        Label6.Text = "Foodname"
        invoiceNo()

    End Sub
    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        ListView1.Items.Clear()
        PictureBox2.Image = Nothing
        TextBox3.Text = "0"
    End Sub
    Private Sub ListView3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView3.SelectedIndexChanged
        Dim index = ListView3.FocusedItem.Index
        Label9.Text = ListView3.Items(index).Text
        showinfo(Label9.Text)
    End Sub

    Private Sub ListView4_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView4.SelectedIndexChanged
        Dim index = ListView4.FocusedItem.Index
        Label9.Text = ListView4.Items(index).Text
        showinfo(Label9.Text)
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        orderItem(Label6.Text)
    End Sub
    Sub sumUpAllItem()
        Try
            Dim TotalSum As Double = 0
            Dim i As ListViewItem
            For Each i In ListView1.Items
                TotalSum += Convert.ToDouble(i.SubItems.Item(3).Text)
            Next
            TextBox3.Text = TotalSum.ToString
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Sub orderItem(ByVal name As String)
        Dim x As Integer
        Dim totalQty, newTotal, remainStock As Double

        If (TextBox4.Text.Equals("")) Or (TextBox2.Text.Equals("")) Or (TextBox6.Text.Equals("")) Then
            MessageBox.Show("Please Enter Quantity!", "Empty Fields", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        ElseIf (Convert.ToInt32(TextBox4.Text) > Convert.ToInt32(TextBox2.Text)) Then
            MessageBox.Show("Quantity number valid !", "Exceeded Stock", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        Else
            Dim quantityInt As Integer = Convert.ToInt32(TextBox4.Text)
            Dim stockInt As Integer = Convert.ToInt32(TextBox2.Text)
            Dim priceDouble As Double = Convert.ToDouble(TextBox6.Text)

            For x = 0 To ListView1.Items.Count - 1
                If ListView1.Items(x).Text = name Then
                    Dim currentQty As Integer = ListView1.Items(x).SubItems(1).Text

                    totalQty = TextBox4.Text + currentQty
                    newTotal = totalQty * TextBox6.Text
                    remainStock = TextBox2.Text - TextBox4.Text
                    ListView1.Items(x).SubItems(1).Text = totalQty
                    ListView1.Items(x).SubItems(3).Text = newTotal
                    connect()
                    Try
                        Dim query As String = "UPDATE `foods` SET `quantity`= @remain WHERE `foodname`= @name"
                        Dim comm = New MySqlCommand(query, conn)
                        With comm
                            .Parameters.AddWithValue("@remain", remainStock)
                            .Parameters.AddWithValue("@name", name)
                            .ExecuteNonQuery()
                        End With
                        retrieves()
                        retrieves1()
                        retrieves2()
                    Catch ex As Exception
                        MsgBox(ex.Message)
                    End Try
                    conn.Close()
                    clear()

                    sumUpAllItem()
                    Return
                End If
            Next x

            Dim answer As Integer
            Dim totalAmount As Double

            If (quantityInt <= stockInt) Then
                answer = stockInt - quantityInt
                totalAmount = quantityInt * priceDouble
                TextBox2.Text = answer.ToString()
                Dim i As ListViewItem
                i = ListView1.Items.Add(name)
                i.SubItems.Add(TextBox4.Text)
                i.SubItems.Add(TextBox6.Text)
                i.SubItems.Add(totalAmount.ToString())
                clear()
                sumUpAllItem()
            End If
            connect()
            Try
                Dim query As String = "UPDATE `foods` SET `quantity`= @answer WHERE `foodname`= @name"
                Dim comm = New MySqlCommand(query, conn)
                With comm
                    .Parameters.AddWithValue("@answer", answer)
                    .Parameters.AddWithValue("@name", name)
                    .ExecuteNonQuery()
                End With
                retrieves()
                retrieves1()
                retrieves2()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            conn.Close()
        End If
    End Sub
    Sub TOTALCASH()
        connect()
        Try
            Dim total As Decimal = TextBox3.Text
            Dim money As Decimal = TextBox1.Text
            If total > money Then
                MessageBox.Show("AMOUNT Not Valid!", "AMOUNT Validation", MessageBoxButtons.OK, MessageBoxIcon.Error)
                TextBox1.Text = ""
            ElseIf total <= money Then
                TextBox5.Text = Val(TextBox1.Text) - Val(TextBox3.Text)
                MessageBox.Show(" CHANGE! " + TextBox5.Text, "SAVE VALIDATION", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Try
                    Dim work As Excel.Workbook
                    Dim app As New Excel.Application
                    Dim sheet As Excel.Worksheet
                    Dim location As String = "C:\Users\bubbles123\Documents\Visual Studio 2013\Projects\Ordering System\SalesandReciepts\Reciept" + DateTime.Now.ToString("dd MMM yyyy hh mm ss") + ".xlsx"
                    app.Workbooks.Add()
                    work = app.ActiveWorkbook
                    sheet = app.ActiveSheet
                    sheet.Cells(1, 2).Value = "---JANESELL MEAL ORDERING SYSTEM---"
                    sheet.Cells(2, 2).Value = "ADDRESS : P2 MAON BUTUAN CITY"
                    sheet.Cells(3, 2).Value = "Contact # : 09103363279"
                    sheet.Cells(4, 1).Value = "DATE : " + Label2.Text
                    sheet.Cells(4, 3).Value = "TIME : " + Label32.Text
                    sheet.Cells(5, 1).Value = "-----------------------------------------------------------------------------------------------------------"
                    sheet.Cells(6, 2).Value = "Sales Invoice " + " : " + "" + invoiceLabel.Text
                    sheet.Cells(7, 2).Value = "YOUR ORDER" + " : "
                    sheet.Cells(9, 2).Value = "Food Name " + "  "
                    sheet.Cells(9, 3).Value = "Quantity  " + ""
                    sheet.Cells(9, 4).Value = "Price " + " "
                    sheet.Cells(9, 5).Value = "Total  " + " "
                    sheet.Cells(18, 1).Value = "----------------------------------------------------------------------------------------------------------"
                    sheet.Cells(19, 2).Value = "AMOUNT :  " + TextBox1.Text
                    sheet.Cells(20, 2).Value = "CHANGES :  " + TextBox5.Text
                    sheet.Cells(21, 2).Value = "TOTAL :   " + TextBox3.Text
                    sheet.Cells(22, 2).Value = "----------------------**ENJOY your meal and comeback again :) **--------------------"
                    sheet.Cells(25, 1).Value = "Customers Name : " + "_____________________________________"
                    sheet.Cells(26, 1).Value = "Address : " + "    _______________________________________"
                    sheet.Cells(27, 1).Value = "Email no. : " + " _______________________________________"
                    sheet.Cells(28, 1).Value = "Date Issued : " + Label2.Text
                    With sheet.Range("A1", "N1")
                        .Font.Bold = True
                        .Font.Size = 10
                        .HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
                        .ColumnWidth = 10
                    End With

                    With sheet.Range("A2", "N2")
                        .Font.Bold = True
                        .HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
                        .ColumnWidth = 10
                    End With

                    With sheet.Range("A3", "N3")
                        .Font.Bold = True
                        .HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
                        .ColumnWidth = 10
                    End With

                    With sheet.Range("A4", "N4")
                        .Font.Bold = True
                        .HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
                        .ColumnWidth = 5
                    End With

                    With sheet.Range("A6", "N6")
                        .Font.Bold = True
                        .Font.Size = 13
                        .HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
                        .ColumnWidth = 5
                    End With

                    With sheet.Range("A7", "N7")
                        .Font.Bold = True
                        .HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
                        .ColumnWidth = 10
                    End With

                    With sheet.Range("A9", "N9")
                        .Font.Bold = True
                        .Font.Size = 10
                        .HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter

                    End With

                    With sheet.Range("A10", "N10")
                        .Font.Size = 12
                        .HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter

                    End With

                    With sheet.Range("A19", "N19")
                        .Font.Bold = True
                        .HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
                        .ColumnWidth = 10
                    End With

                    With sheet.Range("A20", "N20")
                        .Font.Bold = True
                        .HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
                        .ColumnWidth = 10
                    End With

                    With sheet.Range("A21", "N21")
                        .Font.Bold = True
                        .HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
                        .ColumnWidth = 10
                    End With

                    

                    Dim row As Integer = 10
                    Dim col As Integer = 2
                    For Each item As ListViewItem In ListView1.Items
                        For i As Integer = 0 To item.SubItems.Count - 1
                            sheet.Cells(row, col).Value = item.SubItems(i).Text
                            col = col + 1
                        Next
                        sheet.Range("A" & row & "", "N" & row & "").HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter
                        row += 1
                        col = 1
                    Next
                    sheet.SaveAs(location)
                    sheet.PrintOut()
                    MessageBox.Show("Successfully Print! ", "SAVE VALIDATION", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    insert()
                    invoiceNo()
                    ListView1.Items.Clear()
                    clear()
                    work.Close()
                    app.Quit()
                    sheet = Nothing
                    app = Nothing
                    work = Nothing
                Catch ex As Exception
                    MessageBox.Show(ex.Message)
                End Try
            End If
        Catch ex As Exception
            MessageBox.Show("Not Valid!", "POS VALIDATION", MessageBoxButtons.OK, MessageBoxIcon.Stop)
        End Try
    End Sub
    Sub insert()
        connect()
        Try
            Dim query As String
            For Each row As ListViewItem In ListView1.Items()
                With row.SubItems
                    query = String.Format("INSERT INTO `transaction` (`invoiceid`, `total`, `cash`, `date`,  `time`,  `food_id`,  `login_id` ) VALUES ('" & invoiceLabel.Text & "','" & .Item(3).Text & "','" & TextBox1.Text & "','" & Label2.Text & "','" & Label32.Text & "', (SELECT food_id FROM foods WHERE foodname = '" & .Item(0).Text & "'),(SELECT staff_id FROM staff  WHERE f_name =  '" & Label3.Text & "'))")
                End With
                cmd = New MySqlCommand(query, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
            Next
            clear()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        conn.Close()
    End Sub
   

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        For Each i As ListViewItem In ListView1.SelectedItems
            ListView1.Items.Remove(i)
            sumUpAllItem()
        Next
    End Sub

    Private Sub TextBox3_KeyPress1(sender As Object, e As KeyPressEventArgs) Handles TextBox3.KeyPress
        e.Handled = Char.IsDigit(e.KeyChar) Or Not Char.IsDigit(e.KeyChar)
    End Sub

    Private Sub TextBox5_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox5.KeyPress
        e.Handled = Char.IsDigit(e.KeyChar) Or Not Char.IsDigit(e.KeyChar)
    End Sub

    Private Sub TextBox6_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox6.KeyPress
        e.Handled = Char.IsDigit(e.KeyChar) Or Not Char.IsDigit(e.KeyChar)
    End Sub

    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress
        e.Handled = Char.IsDigit(e.KeyChar) Or Not Char.IsDigit(e.KeyChar)
    End Sub

    Private Sub TextBox4_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox4.KeyPress
        e.Handled = e.KeyChar <> ChrW(Keys.Back) And Not Char.IsDigit(e.KeyChar)
    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        e.Handled = e.KeyChar <> ChrW(Keys.Back) And Not Char.IsDigit(e.KeyChar)
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        Try
            Dim totalAmountDouble As Double = Convert.ToDouble(TextBox3.Text)
            Dim cashDouble As Double = Convert.ToDouble(TextBox1.Text)
            Dim change As Double = cashDouble - totalAmountDouble
            TextBox5.Text = Math.Round(change, 2).ToString()
        Catch ex As Exception

        End Try
    End Sub
End Class