﻿Imports MySql.Data.MySqlClient
Imports System.IO
Public Class Admin

    Private Sub employeeBtn_Click(sender As Object, e As EventArgs) Handles employeeBtn.Click
        EmployeeList.MdiParent = Me
        Positionlist.Close()
        foodlist.Close()
        staff_history.Close()
        sales.Close()
        loghistory.Close()
        salesform.Close()
        EmployeeList.Show()
    End Sub

    Private Sub medicineBtn_Click(sender As Object, e As EventArgs)
        staff_history.MdiParent = Me
        EmployeeList.Close()
        foodlist.Close()
        sales.Close()
        loghistory.Close()
        salesform.Close()
        Positionlist.Close()
        staff_history.Show()
    End Sub
    Sub updates_log()

        Dim connection As New MySqlConnection("server=localhost;user id=root;database=dborder")

        Dim parameters(2) As MySqlParameter

        parameters(0) = New MySqlParameter("LOG", MySqlDbType.VarChar)
        parameters(0).Value = Label15.Text
        parameters(1) = New MySqlParameter("DATE", MySqlDbType.VarChar)
        parameters(1).Value = Login.Label4.Text
        parameters(2) = New MySqlParameter("TM", MySqlDbType.VarChar)
        parameters(2).Value = Login.Label5.Text

        Dim cmd As New MySqlCommand()
        cmd.Connection = connection
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "update_loghistory"
        cmd.Parameters.AddRange(parameters)
        connection.Open()
        cmd.ExecuteNonQuery()

        connection.Close()
    End Sub
    Private Sub LogOutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogOutToolStripMenuItem.Click
        updates_log()
        Login.Show()
        Me.Hide()
    End Sub

    Private Sub supplierBtn_Click(sender As Object, e As EventArgs) Handles supplierBtn.Click
        foodlist.MdiParent = Me
        EmployeeList.Close()
        Positionlist.Close()
        sales.Close()
        loghistory.Close()
        salesform.Close()
        staff_history.Close()
        foodlist.Show()
    End Sub

    Private Sub EmployeeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EmployeeToolStripMenuItem.Click
        Positionlist.MdiParent = Me
        foodlist.Close()
        EmployeeList.Close()
        staff_history.Close()
        sales.Close()
        loghistory.Close()
        salesform.Close()
        Positionlist.Show()
    End Sub

    Private Sub salesBtn_Click(sender As Object, e As EventArgs) Handles salesBtn.Click
        staff_history.MdiParent = Me
        Positionlist.Close()
        foodlist.Close()
        EmployeeList.Close()
        sales.Close()
        salesform.Close()
        loghistory.Close()
        staff_history.Show()
    End Sub




    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles ToolStripButton1.Click
        salesform.MdiParent = Me
        Positionlist.Close()
        loghistory.Close()
        EmployeeList.Close()
        foodlist.Close()
        staff_history.Close()
        salesform.Show()
    End Sub

    Private Sub Admin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DisplayEmployee(Login.TextBox1.Text)
        insert_log()
    End Sub
    Sub insert_log()
        Dim connection As New MySqlConnection("server=localhost;user id=root;database=dborder")

        Dim parameters(2) As MySqlParameter

        parameters(0) = New MySqlParameter("ID", MySqlDbType.VarChar)
        parameters(0).Value = Label15.Text

        parameters(1) = New MySqlParameter("DT", MySqlDbType.VarChar)
        parameters(1).Value = Login.Label4.Text

        parameters(2) = New MySqlParameter("TM", MySqlDbType.VarChar)
        parameters(2).Value = Login.Label5.Text

        Dim cmd As New MySqlCommand()
        cmd.Connection = connection
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "insertLogHistory"
        cmd.Parameters.AddRange(parameters)
        connection.Open()
        If cmd.ExecuteNonQuery() = 1 Then
            Login.autogenerate()

        Else
        End If
        connection.Close()
    End Sub
    Sub DisplayEmployee(ByVal password As String)
        connect()
        Try
            Dim query As String
            query = "SELECT * FROM `login_user` , `staff` , `position`  where login_user.staff_id = staff.staff_id  AND  staff.p_id = position.p_id AND pincode = @password"
            Dim comm As New MySqlCommand(query, conn)
            comm.Parameters.AddWithValue("@password", password)
            Dim reader = comm.ExecuteReader
            While reader.Read
                Dim id As String = reader.GetString("login_id")
                Label15.Text = id
                Dim name As String = reader.GetString("f_name")
                Label9.Text = name
                Dim position As String = reader.GetString("position")
                Label10.Text = position
                Dim images() As Byte = reader("image")

                If images.Equals(Nothing) Then
                    PictureBox2.Image = Nothing
                Else
                    Dim ms As New MemoryStream(images)
                    PictureBox2.Image = Image.FromStream(ms)
                End If
            End While

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        conn.Close()
    End Sub


    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If Label11.Location.X + Label11.Width < 0 Then
            Label11.Location = New Point(Me.Width, Label11.Location.Y)
        Else
            Label11.Location = New Point(Label11.Location.X - 5, Label11.Location.Y)
        End If
    End Sub


    Private Sub ToolStripButton2_Click(sender As Object, e As EventArgs) Handles ToolStripButton2.Click
        loghistory.MdiParent = Me
        foodlist.Close()
        EmployeeList.Close()
        Positionlist.Close()
        sales.Close()
        staff_history.Close()
        salesform.Close()
        loghistory.Show()
    End Sub
End Class